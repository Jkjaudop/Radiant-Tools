[Aim]
GunFireBulletTarget=head
Bulletlockontarget=head
AllgunsfireBullettarget=head
Thegunfiresandthebulletautomaticallylocksonthetarget=999999
Gunandbullettracking=999999

[Rateoffireofafirearm]
Rateoffireofafirearm=1\1s
Rateoffireofafirearm=true

import java.io.IOException;
import java.nio.file.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ParseCfgFiles {
    public static void main(String[] args) {
        Path dirPath = Paths.get("/storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Selfaiming.ini");

        try {
            List<Path> cfgFiles = Files.walk(dirPath)
                .filter(p -> p.toString().endsWith(".cfg"))
                .collect(Collectors.toList());

            for (Path cfgFile : cfgFiles) {
                List<String> lines = Files.readAllLines(cfgFile);
                Map<String, String> configMap = new HashMap<>();

                for (String line : lines) {
                    if (line.contains("=") && !line.startsWith("#")) {
                        String[] parts = line.split("=", 2);
                        configMap.put(parts[0].trim(), parts[1].trim());
                    }
                }

                System.out.println("Configuration for " + cfgFile.getFileName() + ": " + configMap);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}