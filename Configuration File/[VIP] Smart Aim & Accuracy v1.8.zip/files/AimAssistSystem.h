#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "NeuralNetwork.h"
#include "WeaponSystemInterface.h"
#include "QuantumRandom.h"
#include "UltimateAimAssistSystem.generated.h"

UENUM(BlueprintType)
enum class EAimAssistMode : uint8
{
    Ghost,      
    Phantom,     
    Predator    
};

USTRUCT(BlueprintType)
struct FTargetSignature
{
    GENERATED_BODY()
    
    UPROPERTY(VisibleAnywhere)
    float ThreatLevel;
    
    UPROPERTY(VisibleAnywhere)
    float Vulnerability;
    
    UPROPERTY(VisibleAnywhere)
    float PriorityScore;
};

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class UUltimateAimAssistSystem : public UActorComponent
{
    GENERATED_BODY()

public:    
    UUltimateAimAssistSystem();

protected:
    virtual void BeginPlay() override;
    virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

private:
    void ExecutePrecisionAiming(float DeltaTime);
    void ApplyNeuralNetworkCorrection(FRotator& TargetRotation, ACharacter* Target);
    void QuantumEntanglementAntiDetection();
    void BehavioralChaosField();
    void TemporalObfuscation();
    ACharacter* FindOptimalTarget() const;
    TArray<ACharacter*> GetAllPotentialTargets() const;
    FTargetSignature CalculateTargetSignature(ACharacter* Target) const;
    FVector CalculateQuantumPredictedPosition(ACharacter* Target) const;
    FVector CalculateBallisticTrajectory(FVector Start, FVector TargetPos, float BulletSpeed) const;
    void InitializeNeuralNetwork();
    UPROPERTY(EditAnywhere, Category = "AimAssist|Core")
    EAimAssistMode AimMode = EAimAssistMode::Predator;
    UPROPERTY(EditAnywhere, Category = "AimAssist|Core", meta=(ClampMin="0.1", ClampMax="2.0"))
    float AimPrecision = 1.8f;
    UPROPERTY(EditAnywhere, Category = "AimAssist|Advanced")
    bool bEnableNeuralPrediction = true;
    UPROPERTY(EditAnywhere, Category = "AimAssist|Advanced")
    bool bEnableQuantumObfuscation = true;
    UPROPERTY()
    UNeuralNetwork* AimDecisionNetwork;
    FQuantumRandomStream QuantumRNG;
    float LastAimTime = 0.0f;
    float QuantumTimeDilation = 1.0f;
    float ChaosFieldTimer = 0.0f;
    TMap<ACharacter*, FTargetSignature> TargetSignatureCache;
    APlayerController* GetPlayerController() const;
    ACharacter* GetPlayerCharacter() const;
    IWeaponSystemInterface* GetCurrentWeapon() const;
};