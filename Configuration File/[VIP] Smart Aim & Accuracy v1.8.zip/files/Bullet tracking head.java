javascript
const fs = require('fs');
const ini = require('ini');

const cheatFeatures = {
  'Character firearm range': '99999.0f',
  'Bullet tracking': 'true',
  'Character shooting area': 'MAX',
  'Bullet tracking part': 'Head',
  'Firearm sight spread': '0',
  'Bullet shooting speed': '99999.9f',
};

const config = {
  Cheats: cheatFeatures
};

const iniString = ini.(config);
fs.writeFileSync('Bullet tracking head.', iniString);
