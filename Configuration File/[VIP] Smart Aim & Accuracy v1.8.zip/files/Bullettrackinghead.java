GameReadingData：["com.tencent.tmgp.pubgmhd"]
<"implement">
<"java">
   <execute>com.tencent.tmgp.pubgmhd<"execute">
{
name：["com.tencent.tmgp.pubgmhd"]
function：<"Bullet tracking">
target：<"head">
attack<"head">
}
{
Bullet tracking intensity："999"
track<"Bullet tracking character's head">
attack<"Track from the head">
Designatedattack<"head">
Trackingtriggermethod<"Automatic triggering of character movement">
Bullet Tracking："True"
}
}
target<"head">
function<"Bullet tracking hits the head">
Bullet tracking intensity："999"
Triggermethod<"All firearms fired">
Bullet Tracking："True"
}
{
Tracking intensity："999"
Hit<"head">
Lockedparts<"head">
Bullet Tracking："True"
}
<"completionofenforcement">
{Identifythegamepackagename=com.tencent.tmgp.pubgmhd}