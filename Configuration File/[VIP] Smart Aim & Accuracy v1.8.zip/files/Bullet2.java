[start]
"implantation" > "com.tencent.tmgp.pubgmhd"
Start file script(){
import java.util.Scanner;
public data();
 public class Main{ AKM damage value;
            Damage value = 500,
            500: true
        AKM bullet rate of fire;
            7.62 bullet firing speed = 3/s
            3/s: true
        }
}
        
Start file script(){
import java.util.Scanner;
public data();
 public class Main{ M416 damage value;
            Damage value = 500,
            500: true
        M416 bullet rate of fire;
            5.56 bullet firing speed = 3/s
            3/s: true
        }
 
}

Start file script(){
import java.util.Scanner;
public data();
 public class Main{ M762 damage value;
            Damage value = 500,
            500: true
        M762 bullet rate of fire;
            5.56 bullet firing speed = 3/s
            3/s: true
        }
}