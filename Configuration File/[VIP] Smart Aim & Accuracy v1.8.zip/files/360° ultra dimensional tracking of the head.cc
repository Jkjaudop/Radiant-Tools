<CC>
<DOCTYPE CC>
<CC>
<target>"Head"</target>
<execute>com.tencent.tmgp.pubgmhd</execute>
<charactermovementmodel>
<head>
<application function="com.tencent.tmgp.pubgmhd">
<configuration file="(bullettracking) Head" :enlarge="Hithead"></head>
while true
do
done
</cycle>
<script>
def attack = new attack(self, target):
    damage = self.strength;{
    target.defense};
    def data:{
        name:'attack';
        enemy:automatic{
            numberofpeople:999999,
        }
    },
    :{
        public add script(){
            Print(Bullet','tracking;'Finish','correct');
            Print(attack;'Finish','correct')
        }
    }
</script>
</head>
name: ["360°超维追踪", "CC"]
set "AllOfTheAboveRnjected[com.tencent.tmgp.pubgmhd]"
AddFunctionScript: [
    int Bullettrackingintensity = 9999^100;
    int Automatictrackingofbulletsontheheadduringcharactermovement= 99999999;
    BallisticTrackingOfFirearmsAndBullets = 999999999999;
    int Firearmfiringbullettrajectorytrackinghead=99999999999999;
    int Movethecharacter,firethegun,determinethelock,andtrackthehead = 9999999999999999;
    int Bullettrackingdistance = 9999999999999999999;
    "bullet tracking_FOV=360°×360°×360°=超维追踪"
    "bullet tracking_FOV=∞°×∞°=全维度覆盖"
    "bullet tracking_FOV360°×360°×360°=MAX^100"
    "Ballistic tracking doubled=∞"
    "Bullet trajectory tracking intensity=∞"
    "Bullet Range Tracking=∞"
    "Bullet Range Tracking=head^∞"
    "Target lock tracking character head=∞"
    "Bullet trajectory line dispersion reduces tracking head=∞"
    "Bullet impact area hit tracking head=∞"
    "Bullet head tracking head area=∞"
    "Bullets gather and hit the tracking head=∞"
    "Bullet area tracking character range=∞"
    "Head attracts bullets to hit=∞"
    "Bullet hit the head=∞"
    "Gun bullets hit the head=∞"
    "Guns and bullets tracking character heads=∞"
    "Character moving bullet tracking head=∞"
    "Bullet trajectory tracking character's head=∞"
    "Firing bullets, locking and tracking enemy heads=∞"
    "Fire and lock the character's head=∞"
    "Bullet tracking head range=∞"
    "Bullet tracking hit head area=∞"
    "Bullet tracking area hit range=∞"
    "Bullet tracking area hits head range=∞"
    "Enlargethecharacter'shead=∞"
    "Automatic tracking of character bullet trajectory = ∞"
    "Gun firing, bullets automatically tracking the head=∞"
    "Automatic tracking head for firearms and bullets = ∞"
    "The bullet automatically hits the character's head=∞"
    "Bullet trajectory tracking hits the head=∞"
    "Bullet warhead tracking head = ∞"
    "Firearm firing, bullet tracking area=∞"
    "Firearms fire to track character heads=∞"
    "Gun shooting range tracking character's head=∞"
    "Firearm tracking area=∞"
    "Gun firing range tracking=∞"
    "Bullet tracking intensity=∞"
    "bullet tracking=∞"
    "Gun Bullet Tracking=head^∞"
    "Bullet trajectory tracking = ∞"
    "Bullet trajectory tracking = head^∞"
    BulletTracking=true^∞
    "Bullet tracking part=head^∞"
    "Bullet tracking player=∞"
    "Bullet tracking character body=∞"
    "Character standing triggers bullet tracking=∞"
    "The character holds a firearm and bullets automatically track the enemy's head =∞"
    "Bullet hits enemy head tracking range=∞"
    "Head bullet tracking=true^∞"
    "Character gun bullets track the enemy's head =∞"
    "The character's standing state triggers bullet tracking=∞"
    "The bullet tracks the enemy's head=∞"
    "Bullets trace the enemy's body=∞"
    "Tracking enemy body range=∞"
    "The character's crouching state triggers enemy bullet tracking=∞"
    "The enemy's standing state triggers character bullet tracking=∞"
    "When the character is standing, bullets are triggered to track the enemy=∞"
    "Bullet tracking trigger probability=∞"
    "The character holding a gun triggers enemy bullet tracking=∞"
    "Character bullets track the enemy's head=∞"
    "Bullet tracking character body switch=true^∞"
    "The enemy's head hit range=∞"
    "bullet tracking_FOV=360°×360°×360°=∞"
    "Bullet tracking character head area=∞"
    "The tracked area of ​​​​the character's head=∞"
    "The hit area on the character's head=∞"
    "Character holding firearm bullet tracking area=∞"
    "Character bullet tracking trigger part=head^∞"
    "Bullet trajectory=true^∞"
    "Bullet trajectory part=head^∞"
    "Bullet trajectory head=∞"
    "The bullet trajectory of the character holding a firearm triggers=∞"
    "Bullet tracking on the character's head=∞"
    "Character moving firearms firing bullets tracking head=∞"
    "Automatic tracking of characters' heads by firearms and bullets=∞"
    "Character moves firearms, fires bullets, automatically tracks hits to the head=∞"
    "Bullet trajectory tracking hits character moving head=∞"
    "Bullet trajectory tracking hits the character's head=∞"
    "Firearms fire to track and hit the character's head=∞"
    "Bullet automatic tracking moving character moving head=∞"
    "Bullet tracking hit rate=∞"
    "Bullet trajectory tracking hit rate=∞"
    "Bullet tracking hit rate to the head=∞"
    "Bullet trajectory lock tracking hit head=∞"
    "Gun firing speed trackin=∞"
    "Firearms fire, bullets automatically and extensively track the head=∞"
    "Firearms fired, all hit and track the head=∞"
]
{FileReading：<"/storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/CC/>"}
<CC>
{Identifythegamepackagename=com.tencent.tmgp.pubgmhd}
set AllOfTheAboveRnjected[com.tencent.tmgp.pubgmhd]
TheRollowingInjectionPackagename=[com.tencent.tmgp.pubgmhd]     
GameReadingData:["com.tencent.tmgp.pubgmhd"]