{
   "Bullet range tracking hits the head":{
      "Bullet range tracking head"："locking"
      "Strength":999999,
      "Power":"Max",
      "strength":999999,
      "intensity":"Max",
     "Character Movement Tracking"",":"360°×360°"
                    int Bullettrackingintensity = 999;
int Automatictrackingofbulletsontheheadduringcharactermovement= 999;
       BallisticTrackingOfFirearmsAndBullets = 999;
        int Firearmfiringbullettrajectorytrackinghead=999;
        int Movethecharacter,firethegun,determinethelock,andtrackthehead = 999;
        int Bullettrackingdistance = 999;
        "bullet tracking_FOV=360°×360=head"
"bullet tracking_FOV=360°×360°"
"bullet tracking_FOV360°×360head=MAX
"Bullet trajectory tracking_FOV=360°×360=head"
"Bullet trajectory tracking_FOV=360°×360°"
            "Bullet tracking intensity=MAX
            "bullet tracking=MAX
            "Gun Bullet Tracking=MAX
     "Bullet Tracking = MAX
     "Bullet trajectory tracking = MAX
          "Guns and bullets tracking character heads=MAX
     "Character moving bullet tracking head=MAX
     "Bullet trajectory tracking character's head=MAX
     "Bullet Rifling Tracking Character's Head=MAX
     "Character moves bullets and warheads to track the head=MAX
     "Character moves firearms, fires bullets, and tracks the head=MAX
               "Gun bullets automatically hit the head=MAX
     "Character moves firearms, fires bullets, and tracks the head=MAX
          "Bullet trajectory tracking hits character moving head=MAX
     "Bullet trajectory tracking hits the character's head=MAX
     "Firearms fire to track and hit the character's head=MAX
     "Bullets gather and hit the head=MAX
     "Bullets gather to track the dead end=MAX
          "Bullet tracking head range=MAX
     "Bullet tracking area hit range=MAX
     "Bullet tracking area hits head range=MAX  
     "Bullet impact area hit tracking head=MAX
          "Head attracts bullets to hit=MAX   
     "Character moving bullet trajectory tracking head=MAX
     "Automatic tracking of character bullet trajectory = MAX
"Gun firing, bullets automatically tracking the head=MAX
     "Automatic tracking head for firearms and bullets = MAX
     "The bullet automatically hits the character's head=MAX
     "Bullet trajectory tracking hits the head=MAX
     "Bullet warhead tracking head = MAX
     "Firearm firing, bullet tracking area=MAX
     "Firearms firing, bullets tracking character's head=MAX
     "Bullet hit the head=MAX
     "Gun bullets hit the head=MAX
   },
   "FireEvent":{
      "Trigger":"PlayerFires"
   },
   "MovementEvent":{
      "Trigger":"BotMoves",
      "Action":"TrackHead"
   },
   "NoZoom":{
      "Speed":"forcedLock",
      "Strength":9999.0,
      "Power":"Max",
            "strength":999999,
      "intensity":"Max",
      "Character Movement Tracking":"360°×360°"
   }
}
{
   "Headdynamictracking":{
      "Bullet tracking speed":"Lock",
      "Strength":999999,
      "Power":"Max",
      "strength":999999,
      "intensity":"Max",
      "Dynamictracking"",":"360°×360°"
      "Character Movement Tracking"",":"360°×360°"
   },
   "FireEvent":{
      "Trigger":"PlayerFires"
   },
   "MovementEvent":{
      "Trigger":"BotMoves",
      "Action":"TrackHead"
   },
   "NoZoom":{
      "Speed":"forcedLock",
      "Strength":9999.0,
      "Power":"Max",
            "strength":999999,
      "intensity":"Max",
      "Dynamictracking_FOV":"360°×360°"
      "Character Movement Tracking"",":"360°×360
   }
   {
   "Head dynamic tracking":{
      "Gyroscope tracking":"Lock",
      "Strength":999999,
      "Power":"Max",
      "strength":999999,
      "intensity":"Max",
     "Static tracking"",":"360°×360°"
      "Dynamictracking"",":"360°×360°"
      "Character Movement Tracking"",":"360°×360
   },
   "FireEvent":{
      "Trigger":"PlayerFires"
   },
   "MovementEvent":{
      "Trigger":"BotMoves",
      "Action":"TrackHead"
   },
   "NoZoom":{
      "Speed":"forcedLock",
      "Strength":9999.0,
      "Power":"Max",
            "strength":999999,
      "intensity":"Max",
      "Statictracking":"360°×360°  
          "Dynamictracking"",":"360°×360°"
      "Character Movement Tracking"",":"360°×360
   }
}