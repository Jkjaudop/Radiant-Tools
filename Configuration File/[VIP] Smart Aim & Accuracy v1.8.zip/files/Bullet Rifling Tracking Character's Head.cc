{
 name:["com.tencent.tmgp.pubgmhd"]
    
 GameReadFileName<CC>
  <DOCTYPE CC>
 <CC>
   <target>"Head"</target>
   <execute>com.tencent.tmgp.pubgmhd<"execute">
   <charactermovementmodel>
<head>
   <application function="com.tencent.tmgp.pubgmhd">
      <configuration file="(bullettracking) Head" :enlarge="Hithead"></head>
    </cycle>
      <public>
while true
do
do
<attack>
    <script>
        def attack = new attack(self, target):
            damage = self.strength;{
   target.defense};
           def data:{
                name:'attack';
                enemy:automatic{
                  numberofpeople:99,
                }
            },
            :{
               public add script(){
                    Print(Bullet','tracking;'Finish','correct');
                    Print(attack;'Finish','correct')
                }
            }
        })
     </script>
 </head>
    name: ["Automatic tracking", "CC"]
    AddFunctionScript: [
            "Bullet tracking intensity=MAX
            "bullet tracking=MAX
            "Gun Bullet Tracking=MAX
     "Bullet Tracking = MAX
     "Bullet trajectory tracking = MAX
     "Automatic tracking of character bullet trajectory = MAX
"Gun firing, bullets automatically tracking the head=MAX
     "Automatic tracking head for firearms and bullets = MAX
     "The bullet automatically hits the character's head=MAX
     "Character Movement Bullet Tracking=MAX
     "Character Movement Bullet Tracking=head
          "Bullet tracking head range=MAX
     "Bullet tracking body range=MAX
     "Bullet tracking area hit range=MAX
     "Character moving bullet tracking head=MAX
     "Bullet trajectory tracking character's head=MAX
     "Character head tracking=MAX
     BulletTracking=true
"Bullet tracking part=head
"Bullet tracking player=MAX
"Bullet tracking character body=MAX
"Character standing triggers bullet tracking=MAX
"The character holds a firearm and bullets automatically track the enemy's head =MAX
"Bullet hits enemy head tracking range=MAX
"Head bullet tracking=true
"Character gun bullets track the enemy's head =MAX
"The character's standing state triggers bullet tracking=MAX
"The bullet tracks the enemy's head=MAX
"Bullets trace the enemy's body=MAX
"Tracking enemy body range=MAX
"The character's crouching state triggers enemy bullet tracking=MAX
"The enemy's standing state triggers character bullet tracking=MAX
"When the character is standing, bullets are triggered to track the enemy=MAX
"Bullet tracking trigger probability=MAX
"The character holding a gun triggers enemy bullet tracking=MAX
"Character bullets track the enemy's head=MAX
"Bullet tracking character body switch=true
"The enemy's head hit range=MAX
"bullet tracking_FOV=360°×360°"
"Bullet tracking character head area=MAX
"The tracked area of ​​​​the character's head=MAX
"The hit area on the character's head=MAX
"Character holding firearm bullet tracking area=MAX
"Character bullet tracking trigger part=head
"Bullet trajectory=true
"Bullet trajectory part=head
"Bullet trajectory head=MAX
"The bullet trajectory of the character holding a firearm triggers=MAX
"Bullet tracking on the character's head=MAX
"Character moving firearms firing bullets tracking head=MAX
"Automatic tracking of characters' heads by firearms and bullets=MAX
"Character moves firearms, fires bullets, automatically tracks hits to the head=MAX
"Bullet trajectory tracking hits character moving head=MAX
"Bullet trajectory tracking hits the character's head=MAX
"Firearms fire to track and hit the character's head=MAX
"Bullet automatic tracking moving character moving head=MAX
     "Automatic tracking of characters' heads by firearms and bullets=MAX
     "Character moves firearms, fires bullets, automatically tracks hits to the head=MAX
          "Bullet warhead tracking head = MAX
     "Firearm firing, bullet tracking area=MAX
     "Firearms firing, bullets tracking character's head=MAX
     "Gun bullets automatically hit the head=MAX
     "Firearms firing, bullets tracking the head=MAX
     "The character moves bullets to track the enemy's head=MAX
     "Head attracts bullets to hit=MAX
     "Bullet hit the head=MAX
     "Gun bullets hit the head=MAX
     "Bullets automatically track enemy heads=MAX
     "Gun Bullet Tracking Head=MAX
     "Guns and bullets tracking character heads=MAX
     "Bullets lock and track the character's head=MAX
          "Bullet tracking area hits head range=MAX  
          "Track the area of the bullet area and hit the body=MAX
     "Bullet impact area hit tracking head=MAX
     "Bullet tracking on the character's head=MAX
]：[completionofenforcement]
    {FileReading：<"/storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/CC/>"}
       <application function="com.tencent.ig">
       <"Hithead">
<CC>
{Identifythegamepackagename=com.tencent.tmgp.pubgmhd}

GameReadingData:["com.tencent.tmgp.pubgmhd"]