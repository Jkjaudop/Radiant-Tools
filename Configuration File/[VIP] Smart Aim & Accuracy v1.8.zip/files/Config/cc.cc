public class Player {
    public boolean Gunshottothehead(100)
    //Assume that the character moves and the gun fires, and the bullet automatically tracks the enemy's head
       public boolean True(100)
         public boolean Guns hit the enemy.(100)
       //All firearms, such as fully automatic rifles, fire automatically and hit the enemy's head
         True(100)
         public boolean 5.56bulletHeadshotrate(100)
         //5.56 bullets automatically track the enemy's head
           //7.62 bullet automatically tracks the head
           True(100)
         public boolean  Charactermodel.(100)
           //The character model is huge.
           True(100)
         Headmodel(100)
         //Enlarge the character's head to increase the hit rate
         True(100)
       public}
       {
  "GunSpeedBoost": {
    "Value": 10,
    "Description": "Gun speed increase"
  },
  "BulletDamageIncrease": {
    "Value": 5,
    "Description": "Bullet damage increased"
  },
  "DistanceLimitation": {
    "Value": 1000,
    "Description": "Distance Limit"
  },
  "BulletTrackingPrecision": {
    "Value": true,
    "Description": "Bullet tracking accuracy"
  },
  "AutoTrackEnemy": {
    "Value": true,
    "Description": "Automatically track enemies"
  },
  "HighDamageWeapon": {
    "Value": 10,
    "Description": "High-damage weapons"
  },
  "NoRecoilMechanism": {
    "Value": true,
    "Description": "Recoilless mechanism"
  },
  "AimAssist360Degree": {
    "Value": true,
    "Description": "360° gun assisted aiming"
  },
  "LockOnTarget": {
    "Value": true,
    "Description": "Lock on target"
  },
  "PlayerSpeedBoost": {
    "Value": 5,
    "Description": "Player speed boost"
  },
  "PlayerActionSpeedUp": {
    "Value": 10,
    "Description": "Player behavior acceleration"
  },
  "SmoothRangeAttack": {
    "Value": true,
    "Description": "Smoothing distance range of the whole body state"
  },
  "MatchmakingMechanism": {
    "Value": true,
    "Description": "Matchmaking Mechanism"
  },
  "EnemyBulletDamageReduction": {
    "Value": 0.8,
    "Description": "Enemy bullet damage reduced"
  },
  "PlayerBulletDamageIncrease": {
    "Value": 10,
    "Description": "Increased player bullet damage"
  }
}