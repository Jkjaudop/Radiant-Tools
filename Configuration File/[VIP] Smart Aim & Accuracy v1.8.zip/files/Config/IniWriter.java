import java.io.*;
import java.util.*;

public class IniWriter {

    private final File iniFile;
    private final Map<String, LinkedHashMap<String, String>> sections = new LinkedHashMap<>();

    public IniWriter(String filePath) {
        this.iniFile = new File(filePath);
    }

    
    public void put(String section, String key, String value) {
        sections.computeIfAbsent(section, k -> new LinkedHashMap<>()).put(key, value);
    }

   
    public void save() throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(iniFile), "UTF-8"))) {
            for (Map.Entry<String, LinkedHashMap<String, String>> entry : sections.entrySet()) {
                writer.write("[" + entry.getKey() + "]\n");
                for (Map.Entry<String, String> kv : entry.getValue().entrySet()) {
                    writer.write(kv.getKey() + "=" + kv.getValue() + "\n");
                }
                writer.write("\n");
            }
        }
    }

   
    public static void main(String[] args) {
        try {
            IniWriter writer = new IniWriter("Android/DefaultCustom.ini");

            
            writer.put("Main_AimAssist", "Enable", "1");
            writer.put("Main_AimAssist", "LockOnTime", "0.12");

            writer.put("Main_AimAssist_Magnet", "Enable", "1");
            writer.put("Main_AimAssist_Magnet", "MagnetStrength", "2.0");

            writer.put("Main_BulletTrack_MagicBullet", "Enable", "1");
            writer.put("Main_BulletTrack_MagicBullet", "DamageOverride", "999");

       
            writer.put("Advanced", "MagicBulletConfig", "{\"enable\":true,\"mode\":\"all\",\"damage\":999}");

            writer.save();
            System.out.println("INI file writing completed!");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}