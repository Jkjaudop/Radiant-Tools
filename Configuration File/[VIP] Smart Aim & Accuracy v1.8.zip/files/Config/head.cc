    Aim head == "lock":
        print("Header")
    Other:Rolenfo
        print("Lockhead")
    shot head == "ChengMingsdeadmother"
        print("Lock")