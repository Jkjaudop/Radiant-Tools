using UnityEngine;
using UnityEngine.UI;

public class WeaponSystem : MonoBehaviour
{
    public Transform bulletSpawnPoint;
    public GameObject bulletPrefab;
    public float bulletSpeed = 500f;
    public float lockOnRange = 100f;
    public float lockOnFOV = 60f;
    public Camera playerCamera;
    
    private bool isLockingOn = false;
    private Transform lockedTarget;
    private LineRenderer lockOnLine;
    private Text lockOnText;

    void Start()
    {
        lockOnLine = gameObject.AddComponent<LineRenderer>();
        lockOnLine.startColor = Color.red;
        lockOnLine.endColor = Color.white;
        lockOnLine.positionCount = 2;
        
        lockOnText = GetComponentInChildren<Text>();
    }
    public void Fire()
    {
        GameObject bullet = Instantiate(bulletPrefab, bulletSpawnPoint.position, bulletSpawnPoint.rotation);
        bullet.GetComponent<Rigidbody>().velocity = bulletSpawnPoint.forward * bulletSpeed;
    }
    void Update()
    {
        if (isLockingOn && lockedTarget != null)
        {
            Vector3 direction = lockedTarget.position - bulletSpawnPoint.position;
            bulletSpawnPoint.rotation = Quaternion.LookRotation(direction);
            
            lockOnLine.SetPosition(0, bulletSpawnPoint.position);
            lockOnLine.SetPosition(1, lockedTarget.position);
            
            lockOnText.text = "LOCK ON";
        }
    }
    void FixedUpdate()
    {
        Collider[] hits = Physics.SphereCastAll(
            bulletSpawnPoint.position, 
            0.5f, 
            playerCamera.transform.forward, 
            lockOnRange);

        if (hits.Length > 0)
        {
            Transform closestHead = null;
            float closestDistance = float.MaxValue;
            
            foreach (var hit in hits)
            {
                if (hit.collider.gameObject.tag == "EnemyHead")
                {
                    float distance = Vector3.Distance(
                        bulletSpawnPoint.position, 
                        hit.transform.position);
                    
                    if (distance < closestDistance)
                    {
                        closestDistance = distance;
                        closestHead = hit.transform;
                    }
                }
            }

            if (closestHead != null)
            {
                isLockingOn = true;
                lockedTarget = closestHead;
            }
            else
            {
                isLockingOn = false;
                lockedTarget = null;
            }
        }
        else
        {
            isLockingOn = false;
            lockedTarget = null;
        }
    }
}