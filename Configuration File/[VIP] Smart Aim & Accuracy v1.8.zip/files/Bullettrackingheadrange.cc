{
 name:["com.tencent.tmgp.pubgmhd"]
    
 GameReadFileName<CC>
  <DOCTYPE CC>
 <CC>
   <target>"Head"</target>
   <execute>com.tencent.tmgp.pubgmhd<"execute">
   <charactermovementmodel>
<head>
   <application function="com.tencent.tmgp.pubgmhd">
      <configuration file="(bullettracking) Head" :enlarge="Hithead"></head>
    </cycle>
      <public>
while true
do
do
<attack>
    <script>
        def attack = new attack(self, target):
            damage = self.strength;{
   target.defense};
           def data:{
                name:'attack';
                enemy:automatic{
                  numberofpeople:99,
                }
            },
            :{
               public add script(){
                    Print(Bullet','tracking;'Finish','correct');
                    Print(attack;'Finish','correct')
                }
            }
        })
     </script>
 </head>
    name: ["Automatic tracking", "CC"]
    set "AllOfTheAboveRnjected[com.tencent.tmgp.pubgmhd]"
    AddFunctionScript: [
               int Bullettrackingintensity = 9999;
int Automatictrackingofbulletsontheheadduringcharactermovement= 9999;
       BallisticTrackingOfFirearmsAndBullets = 9999;
        int Firearmfiringbullettrajectorytrackinghead=9999;
        int Movethecharacter,firethegun,determinethelock,andtrackthehead = 9999;
        int Bullettrackingdistance = 9999;
        BulletTracking=true
         "Bullet tracking intensity=999
        "Bullet tracking=True
              "Bullet tracking intensity=999
        "Bulletim pact head area=True
            "Head range=MAX
            "Bullet tracking head=MAX
"Bullet tracking=head
"Bullet landing point=MAX
"Bullet trajectory tracking=MAX
"Accurate firearm head detonation=MAX
     "Character moves bullets and warheads to track the head=MAX
     "Bullet trajectory tracking hits character moving head=MAX
     "Bullet trajectory tracking hits the character's head=MAX
     "Firearms fire to track and hit the character's head=MAX
     "Bullet automatic tracking moving character moving head=MAX
     "Bullet tracking range=MAX
"Bullet tracking intensity=MAX
"Model of a moving bullet tracking and hitting the head of a character=MAX
"Character movement bullets hit the head range=MAX
  "Automatic head tracking for firearms firing=MAX
       "Bullet tracking head range=MAX
       "Bullet tracking hit head area=MAX
     "Bullet tracking area hit range=MAX
     "Bullet tracking area hits head range=MAX
     "Bullet impact area hit tracking head=MAX
          "Gun bullets hit the head=MAX
     "Bullets automatically track enemy heads=MAX
     "Gun Bullet Tracking Head=MAX
     "Guns and bullets tracking character heads=MAX
     "Character moving bullet tracking head=MAX
     "Bullet trajectory tracking character's head=MAX
     "Bullet Rifling Tracking Character's Head=MAX
     "Bullet trajectory tracking hits the character's head=MAX
     "Firearms fire to track character heads=MAX
     "Gun shooting range tracking character's head=MAX
     "Firearm tracking area=MAX
     "Bullet tracking area=MAX
     "Gun and bullet tracking=MAX
     "Gun and bullet tracking area=head
     "Character moves firearms, fires bullets, and tracks the head=MAX
     "Character moving bullet trajectory tracking head=MAX
          "Character Movement Bullet Tracking=head
     "Bullet locked character head tracking=MAX
     "Bullet locks character's head=MAX
     "Fire to lock the character's head=MAX
     "Bullet target locking and tracking head=MAX
     "Target lock tracking character head=MAX
     "Bullet trajectory line dispersion reduces tracking head=MAX
          "Bullet impact area hit tracking head=MAX
}
    {FileReading：<"/storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/CC/Bullettrackinghead">}
{Identifythegamepackagename=com.tencent.tmgp.pubgmhd}