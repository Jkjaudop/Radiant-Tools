{
  name: ["com.tencent.tmgp.pubgmhd"]
   <DOCTYPE Java>
   <Java>
   <target>"head"</target>
   <execute>com.tencent.tmgp.pubgmhd<"execute">
""BulletTrackingIntensity=MAX
"GunFiringTracking=MAX
"BulletTracking=MAX
"BulletTracking=Head
"BulletAutomaticallyLandsOnTheHead=MAX
"TheBulletAutomaticallyHitsTheEnemy'sHead=MAX
"FirearmsFireBulletsAutomaticallyTrackTheHead=MAX
"AutomaticHeadTrackingOfFiringBullets=MAX
"BulletAutomaticTrackingRange=MAX
"BulletBallisticDispersionArea=-40%
"BulletAutomaticallyTracksTheHead=MAX
"BulletTrajectoryAutomaticTrackingOfCharacters=MAX
"AutomaticTrackingOfCharactersByBulletWarheads=MAX
"AutomaticHeadTrackingOfFirearmsAndBullets=MAX
"BulletTrackingIntensity=MAX
"BulletTracking=MAX
"GunBulletTracking=MAX
"BulletTracking=MAX
"BulletTrajectoryTracking=MAX
"GunShootingRangeTrackingCharacter'sHead=MAX
"FirearmTrackingArea=MAX
"BulletTrackingArea=MAX
"GunAndBulletTracking=MAX
"GunAndBulletTrackingArea=head
"CharacterMovesFirearmsFiresBullets,AndTracksTheHead=MAX
"CharacterMovingBulletTrajectoryTrackingHead=MAX
"BulletTrackingHeadTarget=MAX
"FiringBulletsTrackingTheTarget'sHead=MAX
"Bullettrackinghead="True"
"Bullettrace="head"
"Ballistic-tracking-head="90.0"
"GunShotTracking="True"
"BulletTracking=MAX.0f
"BulletTracking=True
"BulletimPactHeadArea=True
"HeadRange=MAX
"BulletTrackingHead=MAX
"BulletTracking=head
"BulletLandingPoint=MAX
"BulletTrajectoryTracking=MAX
"AccurateFirearmHeadDetonation=MAX
"BulletTrackingRange=MAX
"BulletTrackingIntensity=MAX
"CharacterNovementBulletsHitTheHeadRange=MAX
"AutomaticHeadTrackingForFirearmsFiring=MAX
"GunShotBulletTracking=MAX
"GunFiringBulletTrackingHeadRate=MAX
"GunTracking=max
"GunFiringBulletAreaTracking=MAX
"CharacterMovementTrackingHead=Max
"AutomaticBulletTrackingHitsTheHead=MAX
"TheCharacterStopsMovingAndTracksTheHead=MAX
"trackingRange=max
"Bullet model=MAX
"Model figure range=MAX
"Headform Scope=MAX
"Body type range=MAX
"Body range=MAX
"Head range=MAX
"Character range=MAX
"Leg range==MAX
"Hit range when characters are in motion=MAX
"Area size of character model=MAX
"Character strike area size=MAX
"Character hit rate=MAX
"Area range of characters hit=MAX
"Bullet hit area=MAX
"Firing trigger strike effect=MAX
"Hit area of classic flame=MAX
"Hit range of all guns=MAX
                     }:"execute"
             <Java>