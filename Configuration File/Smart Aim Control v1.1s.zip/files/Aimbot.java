package com.tencent.tmgp.pubgmhd;

public class Main {
    public static void main(String[] args) {
        int FireselfaimingLockingHead = 99.999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999991;

        Firearms m416 = new Firearms();
        m416.applyFireselfaimingLockingHead();

        Firearms aug = new Firearms();
        aug.applyFireselfaimingLockingHead();

        Firearms ak47 = new Firearms();
        ak47.applyFireselfaimingLockingHead();

        Firearms m762 = new Firearms();
        m762.applyFireselfaimingLockingHead();

        Firearms scarL = new Firearms();
        scarL.applyFireselfaimingLockingHead();

        Firearms groza = new Firearms();
        groza.applyFireselfaimingLockingHead();

        Firearms ump45 = new Firearms();
        ump45.applyFireselfaimingLockingHead();

        Firearms uzi = new Firearms();
        uzi.applyFireselfaimingLockingHead();

        Firearms vector = new Firearms();
        vector.applyFireselfaimingLockingHead();

        Firearms p90 = new Firearms();
        p90.applyFireselfaimingLockingHead();

        Firearms mk14 = new Firearms();
        mk14.applyFireselfaimingLockingHead();

        Firearms m249 = new Firearms();
        m249.applyFireselfaimingLockingHead();

        Firearms mg3 = new Firearms();
        mg3.applyFireselfaimingLockingHead();

        Firearms pkm = new Firearms();
        pkm.applyFireselfaimingLockingHead();

        Firearms dp28 = new Firearms();
        dp28.applyFireselfaimingLockingHead();

        Firearms s12k = new Firearms();
        s12k.applyFireselfaimingLockingHead();
    }
}

class Firearms {
    void applyFireselfaimingLockingHead() {
       
    }
}