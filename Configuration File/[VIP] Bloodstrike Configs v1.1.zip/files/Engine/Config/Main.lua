function Mainlua()
run = gg.multiChoice({
"mb head",
"exit",
}, nil, "Activate at start/kill immediately.")
if run == nil then
else
if run[1] == true then
mb1()
end
if run[2] == true then
os.exit()
end
end
fuck = -1
end

function mb1()
gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("0.1099999994;1", gg.TYPE_FLOAT)
gg.refineNumber("0.1099999994", gg.TYPE_FLOAT)
revert = gg.getResults(90000)
gg.editAll("2.25", gg.TYPE_FLOAT)
gg.clearResults()
gg.toast("mb done")
end

while true do
if gg.isVisible(true) then
Shot = 1
gg.setVisible(false)
end
Aim == 1 true
Mainlua()
Heas = -1
end
end