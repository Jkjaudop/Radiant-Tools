(
#SPOFF FAKE DEVICE NON ROOT
settings delete global device_name
settings delete system model 
settings delete global ro.product.model 
settings delete global ro.product.manufacturer
settings delete global ro.vendor.product.cpu.abilist 
settings delete global ro.product.brand
settings delete global ro.product.device 
settings delete global ro.product.manufacturer
settings delete global ro.product.model 
settings delete global product.marketname 
settings delete global ro.soc.vendor Qualcomm
settings delete global ro.product.system_ext.brand 
settings delete global ro.product.system_ext.device 
settings delete global ro.product.system_ext.manufacturer
settings delete global ro.product.system_ext.marketname 
settings delete global ro.product.vendor.cert 
settings delete global ro.product.Aliases
settings delete global ro.build.tf.modelnumber
settings delete global ro.soc.model
settings delete global ro.soc.vendor
settings delete global ro.soc.manufacturer 
settings delete global ro.soc.model
settings delete global ro.product.cpu.abi
settings delete global ro.product.cpu.abilist
settings delete global ro.product.cpu.name 
settings delete global ro.hardware.chipname 
settings delete global ro.vendor.qti.chip_name
) > /dev/null 2>&1