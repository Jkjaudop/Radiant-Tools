(
#Ping Booster 
settings put global private_dns_specifier 1dot1dot1dot1.cloudflare-dns.com
settings put global private_dns_mode hostname
settings put global preferred_network_mode 13
settings put global private_dns_mode hostname
settings put global network_traffic_optimization 1  
settings put global game_traffic_optimization 1  
settings put global restrict_background_data 1  
settings put global mobile_data_always_on 1
device_config put netd_native dot_query_timeout_ms 50  
device_config put netd_native dot_connect_timeout_ms 100
) > /dev/null 2>&1

(
#Wifi Tweak
device_config put wifi badging_threshold_bandwidth_kbps 10000  
device_config put wifi badging_threshold_signal_dbm -65  
device_config put wifi wakeup_enabled false  
device_config put wifi linked_networks_enabled false  
device_config put wifi aggressive_handovers_enabled false  
device_config put wifi avoid_bad_wifi_connections 1
device_config put netd_native dot_connect_timeout_ms 300
device_config put wifi connection_failure_high_thr_percent 25
device_config put netd_native doh 1
device_config put wifi assoc_timeout_high_thr_percent 90
device_config put wifi auth_failure_high_thr_percent 90
device_config put netd_native dot_query_timeout_ms -1
device_config put wifi disconnection_nonlocal_high_thr_percent 85
device_config put wifi assoc_rejection_high_thr_percent 90
device_config put netd_native dot_validation_latency_offset_ms 25
device_config put wifi connection_failure_disconnection_high_thr_percent 85
device_config put netd_native dot_xport_unusable_threshold -1
) > /dev/null 2>&1

(
#Fast connectivity
device_config put connectivity tcp_default_init_rwnd 60  
device_config put connectivity tcp_user_cfg_ack_prioritization_enabled true  
device_config put connectivity tcp_user_cfg_fastopen_enabled true  
device_config put connectivity tcp_user_cfg_delack_enabled true  
device_config put connectivity tcp_user_cfg_westwood_enabled true
) > /dev/null 2>&1

#V4.0
(
settings put system net.ipv4.tcp_timestamps 0
settings put system net.ipv4.tcp_sack 1
settings put system net.ipv4.tcp_tw_recycle 1
settings put system net.ipv4.tcp_tw_reuse 1
settings put system net.ipv4.tcp_window_scaling 1
settings put system net.ipv4.tcp_keepalive_probes 5
settings put system net.ipv4.tcp_fin_timeout 30
settings put system net.ipv4.tcp_keepalive_intvl 30
) > /dev/null 2>&1

(
#MAX DWONLOAD FAST 
settings put global download_manager_max_bytes_over_mobile 21390950
settings put global download_manager_recommended_max_bytes_over_mobile 21390950
) > /dev/null 2>&1

(
#V2WIFIBOOSTER
settings put system ngChannelBondingMode24GHz 1
settings put system ngChannelBondingMode5GHz 1
settings put system ngForce1x1Exception 0
) > /dev/null 2>&1

(
#WIFI LATENCY
settings put system net.ipv4.route.flush 1
settings put system net.ipv4.ip_no_pmtu_disc 0
settings put system net.ipv4.tcp_ecn 0
settings put system net.ipv4.tcp_fack 1
settings put system net.ipv4.tcp_moderate_rcvbuf 1
settings put system net.ipv4.tcp_no_metrics_save 1
settings put system net.ipv4.tcp_rfc1337 1
settings put system net.ipv4.tcp_sack 1
settings put system net.ipv4.tcp_timestamps 1
settings put system net.ipv4.tcp_window_scaling 1
settings put system net.ipv4.tcp_rmem 4096,39000,187000
settings put system net.ipv4.tcp_wmem 4096,39000,187000
settings put system net.ipv4.tcp_mem 187000,187000,187000
settings put system net.tcp.buffersize.default 4096,87380,256960,4096,16384,256960
settings put system net.tcp.buffersize.wifi 4096,87380,256960,4096,16384,256960
settings put system net.tcp.buffersize.umts 4096,87380,256960,4096,16384,256960
settings put system net.tcp.buffersize.gprs 4096,87380,256960,4096,16384,256960
settings put system net.tcp.buffersize.edge 4096,87380,256960,4096,16384,256960
settings put system net.tcp.buffersize.lte 262144,524288,3145728,262144,524288,3145728
settings put system net.tcp.buffersize.hsdpa 6144,262144,1048576,6144,262144,1048576
settings put system net.tcp.buffersize.evdo_b 6144,262144,1048576,6144,262144,1048576
settings put system net.tcp.buffersize.hspa 6144,87380,262144,6144,16384,262144
settings put system ril.enable.fd.plmn.prefix 23402,23410,23411
settings put system ril.fast.dormancy.rule 1
settings put system fast.dormancy 1
settings put system cust.tel.eons 1
) > /dev/null 2>&1

#PingBooster 
(
settings put system net.ipv4.ip_no_pmtu_disc 0
settings put system config.hw_quickpoweron true
settings put system net.ipv4.tcp_ecn 0
settings put system net.ipv4.route.flush 1
settings put system net.core.netdev_max_backlog 5000
settings put system net.core.netdev_budget 2500
settings put system net.ipv4.tcp_fack 1
settings put system net.core.netdev_budget_usecs 250
settings put system net.ipv4.tcp_mem 187000
settings put system net.ipv4.ip_no_pmtu_disc 0
settings put system net.ipv4.route.flush 1
settings put system net.ipv4.tcp_ecn  0
settings put system net.ipv4.tcp_fack 1
) > /dev/null 2>&1