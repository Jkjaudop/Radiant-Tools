#kaze

#!/system/bin/sh

# Reset properti ke default
  setprop persist.game.mode 0
  setprop persist.graphics.smooth_mode 0
  setprop persist.graphics.performance_boost 0
  setprop persist.graphics.low_latency 0

  setprop debug.hwui.renderer opengl
  setprop debug.hwui.use_vulkan false
  setprop debug.sf.enable_hwc_vds false
  setprop persist.sys.fps 0
  setprop vendor.display.fps.switch 0

  setprop debug.sf.latch_unsignaled 0
  setprop debug.sf.enable_gl_backpressure 0