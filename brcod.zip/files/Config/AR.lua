-- Made by ©PTGCONFIGS --

local aim_assist = {
    weapon = "Assault Rifles",
    aim_assist_strength = "Ultra",
    aimbot_lock_speed = "Fast",
    aim_lock_aggression = "Max",
    hitbox_expansion = "32%",
    enhancement_boost = "21%",
    tracking_smoothness = "Ultra",
    fire_response_time = "Instant"
}

return aim_assist
